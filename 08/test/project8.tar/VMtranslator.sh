#!/bin/sh
java VMtranslator $*
