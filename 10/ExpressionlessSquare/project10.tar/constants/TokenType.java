package constants;

/**
 * Created by Ron on 18/05/2016.
 */
public enum TokenType {
    KEYWORD,
    SYMBOL,
    IDENTIFIER,
    INT_CONST,
    STRING_CONST;
}
