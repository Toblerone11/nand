#!/bin/sh
java Assembler $*
